var Leap = require('../lib').Leap

Leap.loop(function(frame) {
  console.log(frame)
})